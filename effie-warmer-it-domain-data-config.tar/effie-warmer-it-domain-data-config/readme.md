Configuration for effie-warmer-it-domain-data
